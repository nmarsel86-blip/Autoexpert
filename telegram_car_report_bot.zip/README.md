
# Telegram Car Report Bot

Этот бот собирает данные по техническому состоянию автомобиля и генерирует отчёт в формате .docx, отправляя его пользователю прямо в Telegram.

## 🚀 Быстрый старт (Deploy to Render)

Нажми на кнопку ниже, чтобы развернуть бота 24/7 на Render:

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME)

🔁 После нажатия тебе нужно будет:
- Ввести имя сервиса (любое);
- Указать переменную окружения `API_TOKEN` со значением:
  ```
  7611156353:AAHKvcNeNoj_MwFD9wdYsBGHT6A3ZR1CvTA
  ```
- Нажать "Apply" и дождаться запуска.

---

## 🛠 Функциональность

- Сбор данных по 45 пунктам техосмотра
- Генерация `.docx` отчёта (Microsoft Word)
- Автоматическая отправка файла пользователю

---

## 📂 Структура проекта

- `bot.py` — основной код Telegram-бота
- `render.yaml` — описание сервиса для Render
- `README.md` — текущая инструкция
- `requirements.txt` — зависимости

---

## 📌 Требования

- Python 3.9+
- Аккаунт Telegram
- Аккаунт Render (https://render.com)
