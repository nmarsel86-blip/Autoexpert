
import logging
from aiogram import Bot, Dispatcher, executor, types
from docx import Document
from datetime import datetime
import os

API_TOKEN = os.getenv("API_TOKEN")

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

user_data = {}

questions = [
    "Марка и модель:", "Год выпуска:", "VIN:", "Пробег:",
    "Тип двигателя:", "Тип трансмиссии:", "Привод:", "Цвет кузова:", "Количество владельцев по ПТС:",
    "Автомобиль участвовал в ДТП? (да/нет):", "История обслуживания:", "Наличие сервисной книжки:",
    "Количество ключей:", "Таможенный статус:", "Общее состояние ЛКП:", "Перекрашенные элементы:",
    "Заменённые элементы:", "Наличие коррозии, вмятин, сколов:", "Стёкла (оригинальность, год):",
    "Состояние оптики:", "Состояние колёс и шин:", "Визуальное состояние двигателя:", "Запуск двигателя:",
    "Работа на холостом ходу:", "Утечки (масло, антифриз и др.):", "Уровни технических жидкостей:",
    "Результаты тест-драйва двигателя:", "Работа КПП при переключениях:", "Пробуксовки, рывки, толчки:",
    "Уровень и состояние масла в КПП:", "Состояние амортизаторов:", "Люфты, посторонние звуки:",
    "Состояние тормозов:", "Работа ручника:", "Поведение при тест-драйве (подвеска/тормоза):",
    "Состояние сидений и обивки:", "Чистота и запахи в салоне:", "Работа климата и мультимедиа:",
    "Работа кнопок, стёкол, регулировок:", "Оснащение (подогревы, камеры и т.п.):",
    "Подключение сканера:", "Ошибки по диагностике:", "Электрика, датчики, модули:",
    "Общая оценка состояния:", "Примерные расходы на устранение замечаний:", "Рекомендация по приобретению:"
]

@dp.message_handler(commands=['start'])
async def start_cmd(message: types.Message):
    user_data[message.from_user.id] = {'answers': [], 'step': 0}
    await message.answer("Привет! Начнём технический осмотр.\n\n" + questions[0])

@dp.message_handler()
async def collect_data(message: types.Message):
    uid = message.from_user.id
    if uid not in user_data:
        await message.answer("Пожалуйста, начните с команды /start")
        return

    data = user_data[uid]
    data['answers'].append(message.text)
    data['step'] += 1

    if data['step'] < len(questions):
        await message.answer(questions[data['step']])
    else:
        filename = generate_report(data['answers'])
        await message.answer_document(open(filename, 'rb'))
        os.remove(filename)
        del user_data[uid]

def generate_report(answers):
    doc = Document()
    doc.add_heading("Отчёт о техническом состоянии автомобиля", level=1)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    doc.add_paragraph(f"Дата осмотра: {now}\n")

    sections = [
        "Автомобиль", "Общая информация", "Кузов и внешний вид", "Двигатель", "Коробка передач",
        "Подвеска и тормоза", "Салон", "Диагностика", "Итог"
    ]
    section_ranges = [(0,9), (9,14), (14,21), (21,27), (27,30), (30,35), (35,40), (40,43), (43,46)]

    for section, (start, end) in zip(sections, section_ranges):
        doc.add_heading(section, level=2)
        for q, a in zip(questions[start:end], answers[start:end]):
            doc.add_paragraph(f"- {q} {a}")

    filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    doc.save(filename)
    return filename

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
